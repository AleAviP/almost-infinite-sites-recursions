from scipy.misc import comb

x = comb(3, 2)