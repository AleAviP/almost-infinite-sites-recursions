# almost-infinite-sites-recursions
Joint work with A. Avalos-Pacheco. Plublically availiable coppy of python-implementation of almost-inifinite-sites-recursions.
